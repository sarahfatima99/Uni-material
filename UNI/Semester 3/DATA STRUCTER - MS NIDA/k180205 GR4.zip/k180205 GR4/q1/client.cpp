#include<iostream>
#include "cal.h"
using namespace std;
int main(){
	cal c;
	c.quad();
}
