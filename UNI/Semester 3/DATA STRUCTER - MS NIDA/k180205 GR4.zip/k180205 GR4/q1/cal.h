#ifndef cal_h
#define cal_h

using namespace std;
class cal{
	float a,b,c,d,r,r1,i;
	public:
		void quad();
			
		
};
#endif
