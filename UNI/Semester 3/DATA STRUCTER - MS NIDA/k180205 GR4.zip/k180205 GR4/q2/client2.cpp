#include<iostream>
#include "student.h"
int main(){
	student s,s1;
    s.inputdata(s);
    s.gethighest(s1);
}
