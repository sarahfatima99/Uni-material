#ifndef student_h
#define student _h
using namespace std;
class student {
		string name[3];
	float gpa[3];
	int semester[3];
	float x;
	float max;
	public:
		void inputdata(student &s);
		void gethighest(student &s1);
};
#endif
